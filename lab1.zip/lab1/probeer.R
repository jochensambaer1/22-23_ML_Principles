```{python}

(prices_log <- OECDGas$price) %>% head
```
